<head>
<!-- Standard Meta -->
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

<!-- Site Properties -->
<title>Our web page</title>

<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/reset.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/site.css">

<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/container.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/grid.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/header.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/image.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/menu.css">

<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/divider.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/dropdown.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/segment.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/button.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/list.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/icon.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/sidebar.css">
<link rel="stylesheet" type="text/css" href="assets/semantic-ui/components/transition.css">

<link rel="stylesheet" type="text/css" href="assets/semantic-ui/semantic.css">
<link rel="stylesheet" type="text/css" href="../assets/css/form.css">


<!-- would like to get rid of this if possible -->
<link rel="stylesheet" type="text/css" href="assets/css/master.css">
<link rel="stylesheet" type="text/css" href="assets/css/responsive.css">

<!-- would like to CDN this if possible -->
<script src="assets/js/jquery.js"></script>

<!-- dependency on jQuery -->
<script src="assets/semantic-ui/components/visibility.js"></script>
<script src="assets/semantic-ui/components/sidebar.js"></script>
<script src="assets/semantic-ui/components/transition.js"></script>
<script src="../assets/js/form.js"></script>


<script src="assets/semantic-ui/semantic.js"></script>

<!-- would like to get rid of this, too if possible -->
<script src="assets/js/site.js"></script>
</head>
