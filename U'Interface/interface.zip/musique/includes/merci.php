<html lang="fr">

<head>

    <meta charset="utf-8">

    <title>Remerciment </title>
    

        <link href="css/stylett.css" rel="stylesheet">
     
    
</head>



<body  style="background-image:url('.jpg'); background-size : cover;  ">
   

   
  <br/>
  <br/>
    <center><h1 style="margin-top:20%; margin-left: 20%;"> Merci 😄 </h1>

    <p><h2>lettre remerciment</h2></p></center>
    
    <br/>
  <br/>
   



   
            

</div>
  
</body>
    

</html>