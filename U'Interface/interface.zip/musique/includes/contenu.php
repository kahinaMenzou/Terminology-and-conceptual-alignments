<!DOCTYPE html>
<html>


<div style="background:url('images/imgcontenu.jpg') 50% 50% no-repeat; background-size:cover; min-height:450px;">
<div class="ui vertical stripe segment">
<a class="ui huge primary button" href="javascript:history.go(-1)"><<--Retour</a>
	
	<div class="ui middle aligned stackable grid container">

<?php include 'includes/compteurvariable.php'; ?>

<!--/////////////////////////// formulaire /////////////////////// -->
		<div class="row">
			<div class="eight wide column">
				<form class="ui large form" action="includes/traitementxml.php" method="post" >
			<div class="ui labeled input">
  		    <div class="ui label">URI 1</div>
  	        <input type="url" id="id1" name="URI1"  value="<?=$a?>">

  	        <div class="ui label">URI 2 </div>
  	        <input type="url" id="id2" name="URI2"  value="<?=$b?>">
  	        <input type="hidden " name="relation" value="=">
      
            
		    </div>
	       
		</div>

	    </div>

    </div>
    </div>
    <center><div class="ui label">SIMILARITE</div>
  	<input type="text"  name="SIMILARITE" value="<?=$c?>"></center>

	  


	  <div class="ui vertical stripe segment">
	    <div class="ui middle aligned stackable grid container">
          
               <div class="eight wide left floated column">
               	<iframe name="frame1" style="width:550px; height: 1000px;"></iframe>
               	</div>
	        
	        <div class="eight wide left floated column">
	        	<iframe name="frame2" style="width:550px; height: 1000px;"></iframe>
	        	</div>
	  </div>
	    </div>





			<div class="row">
				<div class="wrapper"><center>
					<input  class="ui huge primary button" type="submit"  name="nonvalide" value="NO"  />
                    <input  class="ui huge primary button" type="submit"  name="valide" value="YES"/>
				</center></div>

				
</form>
			</div>

<!--/////////////////////////// js affichage dans les fenetres  /////////////////////// -->

<script language="JavaScript"><!-- ;

 window.onload = function openlink () {

var obj1 = document.getElementById("id1")

window.open(' '+obj1.value+'',"frame1");
// -->
 
var obj2 = document.getElementById("id2")

window.open(' '+obj2.value+'',"frame2");}
</script>

