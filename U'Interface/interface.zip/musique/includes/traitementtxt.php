<?php include 'compteur.php'; ?>
<?php include 'compteurvariable.php'; ?>

<?php


$fichier= "C:/wamp64/www/musique/resultatsfinal/resultatsfinal.txt";


if (isset($_POST['valide']) and (!isset($_POST['nonvalide']))){ 

$URI1 = $_POST['URI1']."\n";
$URI2 = $_POST['URI2']."\n";
$SIMILARITE = $_POST['SIMILARITE']."\n";
$VALIDE = $_POST['valide']."\n"."\n";
// Ouverture du fichier
$fichier = fopen($fichier, 'a+');

// Ecriture dans le fichier
fwrite($fichier,"URI1:" . $URI1)."\n"."<br>";
fwrite($fichier, "URI2:" .$URI2)."\n";
fwrite($fichier, "SIMILARITE:" .$SIMILARITE)."\n";
fwrite($fichier, "AVIS EXPERT:" .$VALIDE)."\n";
	
// Fermeture du fichier
fclose($fichier);}

elseif (!isset($_POST['valide']) and (isset($_POST['nonvalide']))){ 

$URI1 = $_POST['URI1']."\n";
$URI2 = $_POST['URI2']."\n";
$SIMILARITE = $_POST['SIMILARITE']."\n";
$NVALIDE = $_POST['nonvalide']."\n"."\n";
// Ouverture du fichier
$fichier = fopen($fichier, 'a+');

// Ecriture dans le fichier
fwrite($fichier,"URI1:" . $URI1)."\n"."<br>";
fwrite($fichier, "URI2:" .$URI2)."\n";
fwrite($fichier, "SIMILARITE:" .$SIMILARITE)."\n";
fwrite($fichier, "AVIS EXPERT:" .$NVALIDE)."\n"."\n";
// Fermeture du fichier
fclose($fichier);
	# code...
}



?>

<script language="javascript">
  alert("Traitement OK" ); 
  document.location.replace("/musique/index.php" ); 
</script> 
