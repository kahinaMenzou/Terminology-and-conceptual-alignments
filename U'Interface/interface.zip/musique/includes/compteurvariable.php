<?php
///////////////////////////////////////////compteur de la variable /////////////////////////

if ((isset($_POST['valide'])) || (isset($_POST['nonvalide']))) { 

$fichier="C:/wamp64/www/musique/fichiercompteur/comptvariable.txt";

// Lecture du fichier s'il existe et incrémente
$cpt0 = 0;
if(file_exists($fichier)) {
   $inF0 = fopen($fichier,"r");
   $cpt0 = intval(trim(fgets($inF0, 4096))) + 5; 
   fclose($inF0); 
}

// Sauvegarde du compteur
$inF0 = fopen($fichier,"w");
fputs($inF0,$cpt0."\n"); 
fclose($inF0);}

$fichier = fopen('C:/wamp64/www/musique/fichiercompteur/comptvariable.txt','r');
$i= fgets($fichier,filesize('C:/wamp64/www/musique/fichiercompteur/comptvariable.txt'));


$file ="C:/Users/amine/Desktop/resultats.txt";

$tab=file($file);
$tab=str_replace("\"","",$tab);

if ($i<count($tab)) {

$i;

$a=$tab[$i];
$b=$tab[$i+1];
$c=$tab[$i+2];}
 
 elseif ($i>=count($tab)) {
   
 
$a= NULL;
$b= NULL;
$c= NULL ;

$file = fopen("C:/wamp64/www/musique/fichiercompteur/comptvariable.txt",'w');
fwrite($file,"0");
fclose($file);

$file = fopen("C:/wamp64/www/musique/fichiercompteur/comptvalide.txt",'w');
fwrite($file,"0");
fclose($file);

$file = fopen("C:/wamp64/www/musique/fichiercompteur/comptnonvalide.txt",'w');
fwrite($file,"0");
fclose($file);

 ?><script language="javascript">
  alert("Le Traitement du fichier est Terminer" ); 
  document.location.replace("/musique/includes/merci.php", );

</script>

 <?php

}?>