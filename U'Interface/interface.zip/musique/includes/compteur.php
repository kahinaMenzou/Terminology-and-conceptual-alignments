<?php

/******************* compteur des triples valider **********************************/
if (isset($_POST['valide'])) { 


$fichier1="C:/wamp64/www/musique/fichiercompteur/comptvalide.txt";

// Lecture du fichier s'il existe et incrémente
$cpt1 = 0;
if(file_exists($fichier1)) {
   $inF1 = fopen($fichier1,"r");
   $cpt1 = intval(trim(fgets($inF1, 4096))) + 1; 
   fclose($inF1); 
}

// Sauvegarde du compteur
$inF1 = fopen($fichier1,"w");
fputs($inF1,$cpt1."\n"); 
fclose($inF1);}


/******************* compteur des triples valider **********************************/
elseif ((isset($_POST['nonvalide']))) {

$fichier2="C:/wamp64/www/musique/fichiercompteur/comptnonvalide.txt";

// Lecture du fichier s'il existe et incrémente
$cpt2 = 0;
if(file_exists($fichier2)) {
   $inF2 = fopen($fichier2,"r");
   $cpt2 = intval(trim(fgets($inF2, 4096))) + 1; 
   fclose($inF2); 
}

// Sauvegarde du compteur
$inF2 = fopen($fichier2,"w");
fputs($inF2,$cpt2."\n"); 
fclose($inF2);}

?>
