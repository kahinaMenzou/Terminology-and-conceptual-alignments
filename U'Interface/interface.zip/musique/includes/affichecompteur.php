
<?php 'includes/compteur.php'; ?>

<?php


$fichier1 = fopen('C:/wamp64/www/musique/fichiercompteur/comptvalide.txt','r');

$value1 = fgets($fichier1,filesize('C:/wamp64/www/musique/fichiercompteur/comptvalide.txt'));

$fichier2 = fopen('C:/wamp64/www/musique/fichiercompteur/comptnonvalide.txt','r');

$value2 = fgets($fichier2,filesize('C:/wamp64/www/musique/fichiercompteur/comptnonvalide.txt'));

echo '<div class="ui label">FICHIER VALIDER =</div>' .$value1 ."<br>" ."<br>" ;
echo '<div class="ui label">FICHIER NON VALIDER =</div>' .$value2 ;
?>
