<!DOCTYPE html>
<html>

<body>




<div class="ui inverted vertical footer segment">

 	
	<div style="position: absolute;top: 20px; right: 20px;">
		<style>
			.zoom { transition: transform .2s;}
            .zoom:hover { transform: scale(1.5);}
            #Bloc1 {float:right;   width:200px ; margin-left: auto;	margin-right: auto;}
            #Bloc2 {float:right;   width:200px ; margin-left: auto; margin-right: auto;}
            #Bloc3 {float:right;   width:200px ; margin-left: auto;	margin-right: auto;}
            #Bloc4 {float:right;   width:200px ; margin-left: auto;	margin-right: auto;}
            #Bloc5 {float:left;    width:450px ; margin-left: auto;	margin-right: auto; }
        </style>

        <div class="zoom" id="Bloc1"><a href="http://radiofrance.fr/" target="_blank"><img src="images/rf.jpg" style="border-radius:50px;width:50px;height:50px;"/>Radio France</a></div>
		<div class="zoom" id="Bloc2"><a href="https://philharmoniedeparis.fr/fr" target="_blank"><img src="images/ph.jpg" style="border-radius:50px;width:50px;height:50px;;"/>Philharmonie</a></div>
		<div class="zoom" id="Bloc3"><a href="https://www.bnf.fr/fr" target="_blank"><img src="images/1.jpg" style="border-radius:50px;width:50px;height:50px;"/>Bibliothèque nationale</a></div>
        <div class="zoom" id="Bloc4"><a href="http://data.doremus.org/" target="_blank"><img src="images/doremus.jpg" style="border-radius:50px;width:50px;height:50px;"/>Doremus</a></div>

        <div id="Bloc5"><?php include 'includes/affichecompteur.php'; ?></div>
		
	</div >	
			
</div>
		
 
</body>
</html>




