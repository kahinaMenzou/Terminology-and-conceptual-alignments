
<?php include 'compteur.php'; ?>

<?php include 'compteurvariable.php'; ?>

<?php

$file ="C:/wamp64/www/musique/resultats.txt";

$tab=file($file);
$tab=str_replace("\"","",$tab);

if ($i<count($tab)) {

$i;

$a=$tab[$i];
$b=$tab[$i+1];
$c=$tab[$i+2];}
 
 elseif ($i>=count($tab)) {
   
 
$a= NULL;
$b= NULL;
$c= NULL ;

$file = fopen("C:/wamp64/www/musique/fichiercompteur/comptvariable.txt",'w');
fwrite($file,"0");
fclose($file);

$file = fopen("C:/wamp64/www/musique/fichiercompteur/comptvalide.txt",'w');
fwrite($file,"0");
fclose($file);

$file = fopen("C:/wamp64/www/musique/fichiercompteur/comptnonvalide.txt",'w');
fwrite($file,"0");
fclose($file);

 ?><script language="javascript">
  alert("Le Traitement du fichier est Terminer" ); 
  document.location.replace("/musique/merci.php" ); 
</script> <?php

}?>

<?php


$dom = new DOMDocument('1.0', 'utf-8');

$racine = $dom->createElement('Alignment');
$dom->appendChild($racine);

$titre = $dom->createElement('map');
$titre1 = $dom->createElement('Cell');
$titre2 = $dom->createElement('entity1');
$titre3 = $dom->createElement('entity2');
$titre4 = $dom->createElement('measure');
$titre5 = $dom->createElement('relation');
$titre6 = $dom->createElement('avisexpert');

$URI1 = $dom->createAttribute('rdf:resource');
$URI2 = $dom->createAttribute('rdf:resource');
$SIMILARITE = $dom->createAttribute('rdf:datatype');
$validation = $dom->createAttribute('avisexpert');
$relation = $dom->createAttribute('relation');


$titre6->appendChild($validation) ;
$titre5->appendChild($relation) ;
$titre4->appendChild($SIMILARITE) ;
$titre3->appendChild($URI2) ;
$titre2->appendChild($URI1) ;


$racine->appendChild($titre);
$titre->appendChild($titre1);
$titre1->appendChild($titre2);
$titre1->appendChild($titre3);
$titre1->appendChild($titre4);
$titre1->appendChild($titre5);
$titre1->appendChild($titre6);


 if ( isset($_POST['URI1'], $_POST['URI2'], $_POST['SIMILARITE'], $_POST['valide'] ,$_POST['relation'])) {
/********AJOUT TITLE********************************************************************************/

$URI1->value = $_POST['URI1'];
$URI2->value = $_POST['URI2'];
$SIMILARITE->value = $_POST['SIMILARITE'];
$validation->value = $_POST['valide'];
$relation->value = $_POST['relation'];

/**************** sauvgarde ******************/
$fichier1 = fopen('C:/wamp64/www/musique/fichiercompteur/comptvalide.txt','r');

$value1 = fgets($fichier1,filesize('C:/wamp64/www/musique/fichiercompteur/comptvalide.txt'));
$nomfichier ="fichier";
$nomfichier = str_replace(' ', '_', $nomfichier); 
$filename = 'C:/wamp64/www/musique/resultatsfinal/valide/'. $nomfichier.$value1.".xml";

$dom->formatOutput = true;
$dom->normalizeDocument();

$dom->save($filename);}




/*********************************************************************************************************************************************************************/

elseif ( isset($_POST['URI1'], $_POST['URI2'], $_POST['SIMILARITE'], $_POST['nonvalide'], $_POST['relation'] )) {

$URI1->value = $_POST['URI1'];
$URI2->value = $_POST['URI2'];
$SIMILARITE->value = $_POST['SIMILARITE'];
$validation->value = $_POST['nonvalide'];
$relation->value = $_POST['relation'];
/**************** sauvgarde ******************/
$fichier2 = fopen('C:/wamp64/www/musique/fichiercompteur/comptnonvalide.txt','r');

$value2 = fgets($fichier2,filesize('C:/wamp64/www/musique/fichiercompteur/comptnonvalide.txt'));

$nomfichier ="fichier";
$nomfichier = str_replace(' ', '_', $nomfichier); 
$filename = 'C:/wamp64/www/musique/resultatsfinal/nonvalide/'. $nomfichier.$value2 .".xml";

$dom->formatOutput = true;
$dom->normalizeDocument();

$dom->save($filename);}



?>

<script language="javascript">
  alert("Traitement OK" ); 
  document.location.replace("/musique/index.php" ); 
</script> 
