<!DOCTYPE html>
<html>
<?php include 'includes/header.php'; ?>

<body>
	<div class="pusher">
		<div class="ui inverted vertical masthead center aligned segment" style="background:#000000(images/imgheader.jpg) 50% 50% no-repeat; background-size:cover; min-height:0px;min-width: 5px ">
			<div class="ui container">
				<div class="ui text container">
					<h1 class="ui inverted header">Alignement des concerts de la philarmonie</h1>
				</div>
			</div>
		</div>
	</div>
	

<?php include 'includes/contenu.php'; ?><br><br>
<?php include 'includes/footer.php'; ?>

</body>
</html>
