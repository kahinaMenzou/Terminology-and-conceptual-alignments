/**************************** 
	
	Semantic UI Components 

*******************************/

$(document).ready(function() {

	// init all modal boxes
	$('.ui.modal').modal()
	;

    // init sidebar and attach to menu open
    $('.ui.sidebar').sidebar('attach events', '.toc.item')
	;

	// init dropdowns
	$('.ui.dropdown')
	  .dropdown()
	;

	// init checkboxes
	$('.ui.checkbox').checkbox()
	;

	// init multi-selector
	$('.ui.multi-select')
	  .dropdown()
	;

	// prepare all tabs
	$('.ui.tabs .item')
	  .tab()
	;

	// init nested checkboxes 
	$('.list .master.checkbox')
	  .checkbox({
	    // check all children
	    onChecked: function() {
	      var
	        $childCheckbox  = $(this).closest('.checkbox').siblings('.list').find('.checkbox')
	      ;
	      $childCheckbox.checkbox('check');
	    },
	    // uncheck all childrenqwe
	    onUnchecked: function() {
	      var
	        $childCheckbox  = $(this).closest('.checkbox').siblings('.list').find('.checkbox')
	      ;
	      $childCheckbox.checkbox('uncheck');
	    }
	  })
	;
	$('.list .child.checkbox')
	  .checkbox({
	    // Fire on load to set parent value
	    fireOnInit : true,
	    // Change parent state on each child checkbox change
	    onChange   : function() {
	      var
	        $listGroup      = $(this).closest('.list'),
	        $parentCheckbox = $listGroup.closest('.item').children('.checkbox'),
	        $checkbox       = $listGroup.find('.checkbox'),
	        allChecked      = true,
	        allUnchecked    = true
	      ;
	      // check to see if all other siblings are checked or unchecked
	      $checkbox.each(function() {
	        if( $(this).checkbox('is checked') ) {
	          allUnchecked = false;
	        }
	        else {
	          allChecked = false;
	        }
	      });
	      // set parent checkbox state, but dont trigger its onChange callback
	      if(allChecked) {
	        $parentCheckbox.checkbox('set checked');
	      }
	      else if(allUnchecked) {
	        $parentCheckbox.checkbox('set unchecked');
	      }
	      else {
	        $parentCheckbox.checkbox('set indeterminate');
	      }
	    }
	  })
	;
})

/**************************************************************************************************** 
	
 Form validations, might need to be removed or tweaked since will be done also on server side 

*****************************************************************************************************/

$(document).ready(function() {

  $( '#login-signup-form .ui.form' ).form({
    on: 'blur',
	  fields: {
    username: {
      identifier : 'username',
      rules: [
        {  
          type   : 'empty',
          prompt : 'Please enter a username'
        }
      ]
    },
    email: {
      identifier : 'email',
      rules: [
        {
          type   : 'email',
          prompt : 'Please enter a valid email address'
        }
      ]
    },
    password: {
      identifier : 'password',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please enter a password'
        },
        {
          type   : 'length[6]',
          prompt : 'Your password must be at least 6 characters'
        }
      ]
    },
    passwordConfirm: {
      identifier : 'confirm-password',
      rules: [
        {
          type   : 'empty',
          prompt : 'Please confirm your password'
        },
        {
          type   : 'match[password]',
          prompt : 'Password doesn\'t match'
        }
      ]
    },
    terms: {
      identifier : 'terms',
      rules: [
        {
          type   : 'checked',
          prompt : 'You must agree to the terms and conditions'
        }
      ]
    }
	}
});

$( '#suggest-a-city-form .ui.form' ).form({
    on: 'blur',
	  fields: {
    email: {
      identifier : 'email',
      rules: [
        {
          type   : 'email',
          prompt : 'Please enter a valid email address'
        }
      ]
    },
	}
});
})

/****************************** 
	
 Gemini Way - site specifics 

*******************************/

$(document).ready(function() {

  // fix menu when passed
  $('.masthead')
    .visibility({
      once: false,
      onBottomPassed: function() {
        $('.fixed.menu').transition('fade in');
      },
      onBottomPassedReverse: function() {
        $('.fixed.menu').transition('fade out');
      }
    })
  ;

// open modal on login click, show login tab
$('.login-trigger').click(function(){ 
		$.tab('change tab', 'login');
		$('.ui.modal.login').modal('show') 
		$("[data-tab]").removeClass('active');
		$("[data-tab='login']" ).addClass('active');
}); 

// open modal on suggest a city click
$('.suggest-a-city').click(function(){ 
		$('.ui.modal.suggest-a-city').modal('show') 
}); 

// open modal on sign up click, show sign up tab
$('.sign-up-trigger').click(function(){ 
      	$.tab('change tab', 'signup');
		$('.ui.modal.login').modal('show') 
		$("[data-tab]").removeClass('active');
		$("[data-tab='signup']" ).addClass('active');
}); 

 // Modal Login Behavior

  // Hide Sign Up side on initialization
  $("[data-tab='signup'].inactive").hide();
  
  $( '.button.signup' ).click(function() {
 
    // Hide Sign In and show Sign Up side with slide down effect
    $( '.ui.segment.signin' )
      .hide()
      .end()
    .find( '.ui.segment.signup' )
      .slideDown();
  });
 
  $( '.button.signin' ).click(function() {
    // Hide Sign Up and show Sign In side with slide down effect
    $( '.ui.segment.signup' )
      .hide()
      .end()
    .find( '.ui.segment.signin' )
      .slideDown();
  });
  
})